package com.example.resepkita.database;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Resep {
    @PrimaryKey(autoGenerate = true)
    public int id = 0;

    public String judul;

    public String deskripsi;

    public String bahan;

    public String langkah;

    public String foto;
}
