package com.example.resepkita.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.resepkita.database.Resep;

import java.util.List;

@Dao
interface ResepDao {
    @Query("SELECT * FROM resep")
    List<Resep> getAllResep();

    @Insert
    void insertResep(Resep... reseps);
}
